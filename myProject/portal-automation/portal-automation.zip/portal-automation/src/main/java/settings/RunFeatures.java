package settings;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import utility.Property;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Features/web/"
		,glue={"com.web.stepdefs"}
		)
public class RunFeatures {

	public static WebDriver driver;
	public static CommandLine command;
	public static DefaultExecuteResultHandler resultHandler;
	public static DefaultExecutor executor;
	private static ChromeDriverService service;

//	public static void main(String args[]) throws Exception {
//		String product = System.getProperty("product");
//		String tag = System.getProperty("tag");
//		System.setProperty("cucumber.options",
//				"--glue com/" + product + "/stepdefs Features/" + product + " --tags " + tag + "");
//		System.setProperty("cucumber.reports.reportPrefix", Property.getProperty("ApplicationName"));
//		JUnitCore junitRunner = new JUnitCore();
//		junitRunner.run(settings.RunFeatures.class);
//	}

	@BeforeClass
	public static void driverSetup() throws Throwable {

		switch (System.getenv("browser")) {
		case "safari":
			driver = new SafariDriver();
			break;

		case "firefox":
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/geckodriver");
			driver = new FirefoxDriver();
			break;

		case "chrome":
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver");
			driver = new ChromeDriver();
			break;
		case "ie":
			try {
			System.setProperty("webdriver.ie.driver", "C:\\automation\\jars\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			break;

		default:
			break;
		}
		System.out.println(Property.getProperty("Url"));
		driver.get(Property.getProperty("Url"));
		Common.simpleWait(5000);

	}

//	@AfterClass
//	public static void tearDown() throws Exception {
//		driver.quit();
//	}

}
