package pages;

public class ApplicationCatalogPage {

}
